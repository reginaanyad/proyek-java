/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.web.rere;
import java.util.LinkedList;
/**
 *
 * @author regin
 */
public class Playlist {
    private String name; // Name of the playlist
    private LinkedList<Film> films; // List of films in the playlist
    private int currentIndex; // Current index in the playlist
    
    // Constructor to initialize the playlist with a name
    public Playlist(String name) {
        this.name = name;
        this.films = new LinkedList<>();
        this.currentIndex = -1; // No film is currently playing
    }

    // Getter for the playlist name
    public String getName() {
        return name;
    }

    // Setter for the playlist name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for the list of films
    public LinkedList<Film> getFilms() {
        return films;
    }

    // Get the size of the playlist
    public int getSize() {
        return films.size();
    }

    // Add a film to the playlist
    public void addFilm(Film film) {
        if (film == null) {
            throw new IllegalArgumentException("Film cannot be null");
        }
        films.add(film);
    }

    // Remove a film from the playlist
    public void removeFilm(Film film) {
        if (film == null) {
            throw new IllegalArgumentException("Film cannot be null");
        }
        films.remove(film);
        if (currentIndex >= films.size()) {
            currentIndex = films.size() - 1; // Adjust the current index if it goes out of bounds
        }
    }
    
    // Play the next film in the playlist
    public void playNextFilm() {
        if (films.isEmpty()) {
            System.out.println("No films in the playlist.");
            return;
        }

        currentIndex = (currentIndex + 1) % films.size();
        Film nextFilm = films.get(currentIndex);
        System.out.println("Now playing: " + nextFilm.getTitle() + " by " + nextFilm.getDirector());
    }

    // Play the previous film in the playlist
    public void playPreviousFilm() {
        if (films.isEmpty()) {
            System.out.println("No films in the playlist.");
            return;
        }

        currentIndex = (currentIndex - 1 + films.size()) % films.size();
        Film prevFilm = films.get(currentIndex);
        System.out.println("Now playing: " + prevFilm.getTitle() + " by " + prevFilm.getDirector());
    }

    // Play a random film in the playlist
    public void playRandomFilm() {
        if (films.isEmpty()) {
            System.out.println("No films in the playlist.");
            return;
        }

        currentIndex = (int) (Math.random() * films.size());
        Film randomFilm = films.get(currentIndex);
        System.out.println("Now playing: " + randomFilm.getTitle() + " by " + randomFilm.getDirector());
    }
}
