/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.web.rere;

/**
 *
 * @author regin
 */
public class Stack<T> extends LinkedList<T> {

    // Push a new element onto the stack
    public void push(T data) {
        add(data);
    }

    // Pop an element from the stack, throw an exception if the stack is empty
    public T pop() throws Exception {
        if (head == null) throw new Exception("Stack is empty");
        
        Node<T> current = head;
        Node<T> previous = null;

        // Traverse to the last element
        while (current.next != null) {
            previous = current;
            current = current.next;
        }

        if (previous != null) {
            previous.next = null;
        } else {
            head = null; // Stack is now empty
        }

        return current.data;
    }
    
}
