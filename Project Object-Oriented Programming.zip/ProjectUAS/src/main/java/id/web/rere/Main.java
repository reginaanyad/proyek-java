/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package id.web.rere;
import java.util.LinkedList;
import java.util.Scanner;
/**
 *
 * @author regin
 */
public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LinkedList<Film> availableFilms = new LinkedList<>();
        
        // Create a new playlist
        System.out.print("Enter the name of your playlist: ");
        String playlistName = scanner.nextLine();
        Playlist playlist = new Playlist(playlistName);

        // Linked list to store all transactions
        LinkedList<Transaction> transactions = new LinkedList<>();

        // Main menu for different actions
        while (true) {
            System.out.println("========== Welcome to Your Playlist: " + playlistName + " ============");
            System.out.println("Choose an action: ");
            System.out.println("---------- Manage your whislist ---------------");
            System.out.println("1. See your wishlist");
            System.out.println("2. Add a new film to your whislist");
            System.out.println("3. Delete a film from your whislist");
            System.out.println("4. Update film details in your whislist");
            System.out.println("---------- Manage your playlist ---------------");
            System.out.println("5. View films in your playlist");
            System.out.println("6. Remove a film from the playlist");
            System.out.println("---------- Manage your transaction ------------");
            System.out.println("7. Buy or Rent Film");
            System.out.println("8. View transactions list");
            System.out.println("9. Update a transaction");
            System.out.println("10. Delete a transaction");
            System.out.println("---------- Play and Rate the film -------------");
            System.out.println("11. Play a film");
            System.out.println("12. Play a random film");
            System.out.println("13. Rate a film");
            System.out.println("14. Exit");
            System.out.println("Enter your choice: ");
            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 15.");
                continue;
            }
            System.out.println("=======================================================");
            switch (choice) {
                case 1:
                    // View available films
                    if (availableFilms.isEmpty()) {
                        System.out.println("No films available. Please add a film first.");
                    } else {
                        System.out.println("Available films:");
                        for (Film film : availableFilms) {
                            System.out.println("Title: " + film.getTitle() + ", Director: " + film.getDirector() + ", Rating: " + (film.getRating() >= 0 ? film.getRating() : "Not rated"));
                        }
                    }
                    break;
                case 2:
                    // Add a new film
                    String title;
                    String director;

                    while (true) {
                        System.out.print("Enter film title: ");
                        title = scanner.nextLine();
                        if (title == null || title.trim().isEmpty()) {
                            System.out.println("Film title cannot be empty. Please enter a valid title.");
                        } else {
                            break;
                        }
                    }

                    while (true) {
                        System.out.print("Enter film director: ");
                        director = scanner.nextLine();
                        if (director == null || director.trim().isEmpty()) {
                            System.out.println("Film director cannot be empty. Please enter a valid director.");
                        } else {
                            break;
                        }
                    }

                    availableFilms.add(new Film(title, director));
                    System.out.println("Film added.");
                    break;
                case 3:
                    // Delete a film from available films
                    System.out.print("Enter the title of the film to delete: ");
                    String filmTitleToDelete = scanner.nextLine();
                    Film filmToDelete = null;
                    for (Film film : availableFilms) {
                        if (film.getTitle().equalsIgnoreCase(filmTitleToDelete)) {
                            filmToDelete = film;
                            break;
                        }
                    }
                    if (filmToDelete != null) {
                        availableFilms.remove(filmToDelete);
                        System.out.println("Film deleted.");
                    } else {
                        System.out.println("Film not found in available films.");
                    }
                    break;
                case 4:
                    // Update film details
                    System.out.print("Enter the title of the film to update: ");
                    String filmTitleToUpdate = scanner.nextLine();
                    Film filmToUpdate = null;
                    for (Film film : availableFilms) {
                        if (film.getTitle().equalsIgnoreCase(filmTitleToUpdate)) {
                            filmToUpdate = film;
                            break;
                        }
                    }
                    if (filmToUpdate != null) {
                        System.out.print("Enter new title: ");
                        String newTitle = scanner.nextLine();
                        System.out.print("Enter new director: ");
                        String newDirector = scanner.nextLine();
                        filmToUpdate.setTitle(newTitle);
                        filmToUpdate.setDirector(newDirector);
                        System.out.println("Film details updated.");
                    } else {
                        System.out.println("Film not found in available films.");
                    }
                    break;
                case 5:
                    // View films in playlist
                    System.out.println("Films in playlist \"" + playlist.getName() + "\":");
                    for (Film film : playlist.getFilms()) {
                        System.out.println("Title: " + film.getTitle() + ", Director: " + film.getDirector());
                    }
                    break;
                case 6:
                    // Remove a film from the playlist
                    System.out.print("Enter the title of the film to remove: ");
                    String filmTitleToRemove = scanner.nextLine();
                    Film filmToRemove = null;
                    for (Film film : playlist.getFilms()) {
                        if (film.getTitle().equalsIgnoreCase(filmTitleToRemove)) {
                            filmToRemove = film;
                            break;
                        }
                    }
                    if (filmToRemove != null) {
                        playlist.removeFilm(filmToRemove);
                        System.out.println("Film removed from the playlist.");
                    } else {
                        System.out.println("Film not found in the playlist.");
                    }
                    break;
                case 7:
                    // Create a transaction
                    if (playlist.getSize() >= 10) {
                        System.out.println("Playlist is full. Please remove a film before adding a new one.");
                        continue;
                    }

                    String transactionType;
                    while (true) {
                        System.out.print("Enter transaction type (rent/buy) or 'back' to return to menu: ");
                        transactionType = scanner.nextLine();
                        if (transactionType.equalsIgnoreCase("rent") || transactionType.equalsIgnoreCase("buy") || transactionType.equalsIgnoreCase("back")) {
                            break;
                        } else {
                            System.out.println("Wrong input. Please enter 'rent', 'buy', or 'back'.");
                        }
                    }

                    if (transactionType.equalsIgnoreCase("back")) {
                        continue;
                    }

                    System.out.print("Enter the title of the film for the transaction: ");
                    String transactionFilmTitle = scanner.nextLine();
                    Film transactionFilm = null;
                    for (Film film : availableFilms) {
                        if (film.getTitle().equalsIgnoreCase(transactionFilmTitle)) {
                            transactionFilm = film;
                            break;
                        }
                    }

                    if (transactionFilm != null) {
                        Transaction transaction = new Transaction(transactionFilm, playlist, transactionType);
                        transactionFilm.addTransaction(transaction);
                        transactions.add(transaction);
                        System.out.println("Transaction created: " + transaction);

                        // Add the film to the playlist after transaction
                        playlist.addFilm(transactionFilm);
                        System.out.println("Film added to the playlist.");
                    } else {
                        System.out.println("Film not found in available films.");
                    }
                    break;
                case 8:
                    // View transactions
                    System.out.println("Transactions:");
                    for (Transaction transaction : transactions) {
                        System.out.println(transaction);
                    }
                    break;
                case 9:
                    // Update a transaction
                    System.out.print("Enter the title of the film for the transaction to update: ");
                    String filmTitleForTransactionUpdate = scanner.nextLine();
                    Transaction transactionToUpdate = null;
                    for (Transaction transaction : transactions) {
                        if (transaction.getFilm().getTitle().equalsIgnoreCase(filmTitleForTransactionUpdate)) {
                            transactionToUpdate = transaction;
                            break;
                        }
                    }
                    if (transactionToUpdate != null) {
                        System.out.print("Enter new transaction type (rent/buy): ");
                        String newTransactionType = scanner.nextLine();
                        if (newTransactionType.equalsIgnoreCase("rent") || newTransactionType.equalsIgnoreCase("buy")) {
                            transactionToUpdate.setType(newTransactionType);
                            System.out.println("Transaction updated.");
                        } else {
                            System.out.println("Invalid transaction type. Transaction not updated.");
                        }
                    } else {
                        System.out.println("Transaction not found.");
                    }
                    break;
                case 10:
                    // Delete a transaction
                    System.out.print("Enter the title of the film for the transaction to delete: ");
                    String filmTitleForTransactionDelete = scanner.nextLine();
                    Transaction transactionToDelete = null;
                    for (Transaction transaction : transactions) {
                        if (transaction.getFilm().getTitle().equalsIgnoreCase(filmTitleForTransactionDelete)) {
                            transactionToDelete = transaction;
                            break;
                        }
                    }
                    if (transactionToDelete != null) {
                        transactions.remove(transactionToDelete);
                        System.out.println("Transaction deleted.");
                    } else {
                        System.out.println("Transaction not found.");
                    }
                    break;
                case 11:
                   // Play a film
                    System.out.print("Enter the title of the film to play: ");
                    String filmTitleToPlay = scanner.nextLine();
                    Film filmToPlay = null;
                    for (Film film : playlist.getFilms()) {
                        if (film.getTitle().equalsIgnoreCase(filmTitleToPlay)) {
                            filmToPlay = film;
                            break;
                        }
                    }
                    if (filmToPlay != null) {
                        System.out.println("Playing \"" + filmToPlay.getTitle() + "\" by " + filmToPlay.getDirector());
                        while (true) {
                            System.out.print("Enter 'next' to play the next film, 'prev' to play the previous film, or 'stop' to return to the main menu: ");
                            String playChoice = scanner.nextLine();
                            if (playChoice.equalsIgnoreCase("next")) {
                                playlist.playNextFilm();
                            } else if (playChoice.equalsIgnoreCase("prev")) {
                                playlist.playPreviousFilm();
                            } else if (playChoice.equalsIgnoreCase("stop")) {
                                break;
                            } else {
                                System.out.println("Invalid input. Please enter 'next', 'prev', or 'stop'.");
                            }
                        }
                    } else {
                        System.out.println("Film not found in the playlist.");
                    }
                    break;
                case 12:
                    // Play a random film
                    playlist.playRandomFilm();
                    System.out.println("Enter 'stop' to return to the main menu.");
                    scanner.nextLine();
                    break;
                case 13:
                    // Rate a film
                    System.out.print("Enter the title of the film to rate: ");
                    String filmTitleToRate = scanner.nextLine();
                    Film filmToRate = null;
                    for (Film film : availableFilms) {
                        if (film.getTitle().equalsIgnoreCase(filmTitleToRate)) {
                            filmToRate = film;
                            break;
                        }
                    }
                    if (filmToRate != null) {
                        System.out.print("Enter new rating (0-10): ");
                        double newRating;
                        while (true) {
                            try {
                                newRating = Double.parseDouble(scanner.nextLine());
                                if (newRating >= 0 && newRating <= 10) {
                                    break;
                                } else {
                                    System.out.println("Rating must be between 0 and 10. Please enter again: ");
                                }
                            } catch (NumberFormatException e) {
                                System.out.println("Invalid input. Please enter a number between 0 and 10: ");
                            }
                        }
                        filmToRate.setRating(newRating);
                        System.out.println("Film rating updated.");
                    } else {
                        System.out.println("Film not found in available films.");
                    }
                    break;
                case 14:
                    // Exit the program
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}