/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.web.rere;

/**
 *
 * @author regin
 */
public class Film {
    private String title; // Title of the film
    private String director; // Director of the film
     private double rating; // Rating of the film
    private LinkedList<Transaction> transactions; // List of transactions associated with this film

    // Constructor to initialize the film with a title and director
    public Film(String title, String director) {
        this.title = title;
        this.director = director;
        this.rating = -1; // Initialize with an invalid rating
        this.transactions = new LinkedList<>();
    }

    // Getter for the film title
    public String getTitle() {
        return title;
    }

    // Setter for the film title
    public void setTitle(String title) {
        this.title = title;
    }

    // Getter for the film director
    public String getDirector() {
        return director;
    }

    // Setter for the film director
    public void setDirector(String director) {
        this.director = director;
    }
    
    // Getter for the film rating
    public double getRating() {
        return rating;
    }
    
    // Setter for the film rating
    public void setRating(double rating) {
        this.rating = rating;
    }
    
    // Add a transaction to the film
    public void addTransaction(Transaction transaction) {
        transactions.add(transaction);
    }

    // Getter for the list of transactions
    public LinkedList<Transaction> getTransactions() {
        return transactions;
    }

    // Override the toString method to provide a string representation of the film
    @Override
    public String toString() {
        return "Title: " + title + ", Director: " + director + ", Rating: " + (rating >= 0 ? rating : "Not rated");
    }
}
