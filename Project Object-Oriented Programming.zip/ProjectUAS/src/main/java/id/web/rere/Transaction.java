/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.web.rere;

/**
 *
 * @author regin
 */
public class Transaction {
    private Film film; // The film involved in the transaction
    private Playlist playlist; // The playlist associated with the transaction
    private String type; // Type of transaction: rent or buy

    // Constructor to initialize the transaction with a film, playlist, and type
    public Transaction(Film film, Playlist playlist, String type) {
        this.film = film;
        this.playlist = playlist;
        this.type = type;
    }

    // Getter for the film
    public Film getFilm() {
        return film;
    }
    
    public void setFilm(Film film) {
        this.film = film;
    }
    
    // Getter for the playlist
    public Playlist getPlaylist() {
        return playlist;
    }
    
    public void setPlaylist(Playlist playlist) {
        this.playlist = playlist;
    }
    // Getter for the type of transaction
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
            
    // Override the toString method to provide a string representation of the transaction
    @Override
    public String toString() {
        return "Transaction: " + type + " - Film: " + film.getTitle() + " - Playlist: " + playlist.getName();
    }
}
