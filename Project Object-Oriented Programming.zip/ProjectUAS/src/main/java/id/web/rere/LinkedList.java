/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.web.rere;
import java.util.Iterator;
/**
 *
 * @author regin
 */
public class LinkedList<T> implements Iterable<T> {
    protected Node<T> head; // Head node of the linked list
    private int size; // Size of the linked list

    // Node class to represent each element in the linked list
    public class Node<T> {
        T data; // Data of the node
        Node<T> next; // Reference to the next node

        // Constructor to initialize a node with data
        Node(T data) {
            this.data = data;
            this.next = null;
        }
    }

    // Constructor to initialize an empty linked list
    public LinkedList() {
        this.head = null;
        this.size = 0;
    }

    // Add a new element to the end of the linked list
    public void add(T data) {
        Node<T> newNode = new Node<>(data);
        if (head == null) {
            head = newNode;
        } else {
            Node<T> current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        size++;
    }

    // Remove an element from the linked list
    public void remove(T data) {
        if (head == null) {
            return;
        }

        if (head.data.equals(data)) {
            head = head.next;
            size--;
            return;
        }

        Node<T> current = head;
        while (current.next != null && !current.next.data.equals(data)) {
            current = current.next;
        }

        if (current.next != null) {
            current.next = current.next.next;
            size--;
        }
    }

    // Get the size of the linked list
    public int size() {
        return size;
    }

    // Check if the linked list contains a specific element
    public boolean contains(T data) {
        Node<T> current = head;
        while (current != null) {
            if (current.data.equals(data)) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    // Override the iterator method to provide an iterator for the linked list
    @Override
    public Iterator<T> iterator() {
        return new LinkedListIterator();
    }

    // Iterator class to iterate over the linked list
    private class LinkedListIterator implements Iterator<T> {
        private Node<T> current = head; // Current node in the iteration

        // Check if there are more elements to iterate over
        @Override
        public boolean hasNext() {
            return current != null;
        }

        // Get the next element in the iteration
        @Override
        public T next() {
            T data = current.data;
            current = current.next;
            return data;
        }
    }
}
